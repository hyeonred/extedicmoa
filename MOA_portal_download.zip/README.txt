# 모아(MOA) 포털

## 파일
- `index.html`: 모아 홈 화면
- `search.html`: 전용 검색 결과 페이지

## 배포
두 파일을 같은 폴더(저장소 루트)에 업로드한 뒤 GitHub Pages 또는 Vercel로 배포하세요.

## Google Programmable Search Engine 설정
검색엔진 ID는 `535bc4f986ce24247`로 연결되어 있습니다.
검색엔진 관리 화면의 검색 대상(Sites to search)에 아래 세 도메인을 모두 추가해야 합니다.
- `blog.extedic.com`
- `sns.extedic.com`
- `wikis.krsocsci.org`

검색 범위는 사이트 내 검색 페이지에서 `site:` 조건으로 구분합니다. 검색 결과는 `search.html` 안에 표시됩니다.
검색 결과 노출은 구글 색인 상태 및 검색엔진 설정에 따라 달라질 수 있습니다.
